package com.tc.empspringmvc.common;

public interface EMPConstants {
	String PROPERTY_FILENAME = "classpath:emp.properties";
	String VIEW_LOGINPAGE = "loginPage";
	String VIEW_HOMEPAGE = "homePage";
	String DB_INTERACTION_TYPE="hibernate";
}
